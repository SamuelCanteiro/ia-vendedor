# IA Vendedor — versão 2

Esta versão mantém o protótipo original e adiciona uma camada preparada para IA real.

## Rodar localmente

```bash
pnpm install
pnpm dev
```

## Ativar IA real

1. Copie `.env.example` para `.env.local`.
2. Preencha `AI_API_KEY` com uma chave do provedor escolhido.
3. Defina `AI_MODEL` conforme o modelo disponível na sua conta.
4. Se o provedor for compatível com a API OpenAI Chat Completions, mantenha `AI_BASE_URL` ou altere para a URL do provedor.
5. Reinicie o servidor.

A chave é lida somente no servidor e não é enviada para o navegador.

Sem chave, o sistema continua funcionando com o gerador local/fallback.

## O que foi adicionado

- `lib/ai/config.ts`: configuração segura por variáveis de ambiente.
- `lib/ai/openai-compatible.ts`: cliente server-side sem expor a chave.
- `lib/ai/campaign-generator.ts`: geração real de campanhas com fallback local.
- `lib/ai/sales-assistant.ts`: vendedor virtual que consulta empresa e catálogo.
- `app/(app)/atendimento/actions.ts`: Server Action para respostas do atendimento.
- `.env.example`: modelo de configuração.

## Importante

O protótipo ainda usa dados demo e armazenamento local. Para colocar clientes reais usando o sistema, a próxima etapa é trocar `lib/data/catalog.ts` e `campaign-store.ts` por um banco de dados e autenticação.
