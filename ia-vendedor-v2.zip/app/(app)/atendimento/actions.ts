'use server'

import { generateSalesReply, type SalesMessage } from '@/lib/ai/sales-assistant'

export async function replyToCustomer(history: SalesMessage[]) {
  try {
    const safeHistory = history.slice(-12).map((message) => ({
      role: message.role === 'assistant' ? 'assistant' as const : 'user' as const,
      content: message.content.slice(0, 2000),
    }))
    return { ok: true as const, ...(await generateSalesReply(safeHistory)) }
  } catch {
    return { ok: false as const, message: 'Não consegui gerar uma resposta agora. Tente novamente.' }
  }
}
