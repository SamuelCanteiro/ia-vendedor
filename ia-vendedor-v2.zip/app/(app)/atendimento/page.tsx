import { PageHeader } from '@/components/page-header'
import { SupportInbox } from '@/components/support/support-inbox'

export default function AtendimentoPage() {
  return (
    <>
      <PageHeader
        eyebrow="Atendimento IA"
        title="Atendimento inteligente"
        description="A IA responde seus clientes 24h com base nos seus produtos e preços."
      />
      <SupportInbox />
    </>
  )
}
