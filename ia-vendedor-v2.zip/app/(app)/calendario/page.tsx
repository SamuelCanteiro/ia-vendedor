import { PageHeader } from '@/components/page-header'
import { calendarEvents } from '@/lib/demo-data'
import { cn } from '@/lib/utils'

const weekdays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']
const typeStyle = {
  post: 'bg-primary/15 text-primary',
  campanha: 'bg-success/15 text-success',
  lembrete: 'bg-[oklch(0.8_0.14_80)]/15 text-[oklch(0.82_0.14_80)]',
} as const
const typeLabel = { post: 'Post', campanha: 'Campanha', lembrete: 'Lembrete' } as const

const FIRST_WEEKDAY = 1
const DAYS_IN_MONTH = 30
const TODAY = 10

export default function CalendarioPage() {
  const cells = [...Array(FIRST_WEEKDAY).fill(null), ...Array.from({ length: DAYS_IN_MONTH }, (_, i) => i + 1)]

  return (
    <>
      <PageHeader eyebrow="Calendário" title="Junho de 2026" description="Planeje e acompanhe suas publicações e campanhas." />

      <div className="mb-4 flex flex-wrap gap-3">
        {(Object.keys(typeLabel) as (keyof typeof typeLabel)[]).map((t) => (
          <span key={t} className={cn('rounded-full px-3 py-1 text-xs font-medium', typeStyle[t])}>
            {typeLabel[t]}
          </span>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_300px]">
        <div className="panel hidden overflow-hidden md:block">
          <div className="grid grid-cols-7 border-b border-border">
            {weekdays.map((d) => (
              <div key={d} className="p-3 text-center text-xs font-semibold text-muted-foreground">
                {d}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7">
            {cells.map((day, i) => {
              const events = calendarEvents.filter((e) => e.day === day)
              return (
                <div key={i} className="min-h-24 border-r border-b border-border p-2 [&:nth-child(7n)]:border-r-0">
                  {day && (
                    <>
                      <span
                        className={cn(
                          'flex size-7 items-center justify-center rounded-full text-xs',
                          day === TODAY ? 'bg-primary font-bold text-primary-foreground' : 'text-muted-foreground',
                        )}
                      >
                        {day}
                      </span>
                      <div className="mt-1 flex flex-col gap-1">
                        {events.map((e) => (
                          <span key={e.title} className={cn('truncate rounded px-1.5 py-0.5 text-[11px] font-medium', typeStyle[e.type])}>
                            {e.title}
                          </span>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        <section className="panel p-5" aria-labelledby="upcoming">
          <h2 id="upcoming" className="mb-4 font-semibold">
            Próximos agendamentos
          </h2>
          <ul className="flex flex-col gap-3">
            {calendarEvents.map((e) => (
              <li key={e.title} className="flex items-center gap-3">
                <span
                  className={cn(
                    'flex size-11 shrink-0 flex-col items-center justify-center rounded-xl border border-border text-xs leading-tight',
                    e.day === TODAY && 'border-primary bg-primary/10',
                  )}
                >
                  <span className="font-bold">{String(e.day).padStart(2, '0')}</span>
                  <span className="text-[10px] text-muted-foreground">jun</span>
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{e.title}</p>
                  <span className={cn('mt-0.5 inline-block rounded px-1.5 text-[10px] font-medium', typeStyle[e.type])}>
                    {typeLabel[e.type]}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </>
  )
}
