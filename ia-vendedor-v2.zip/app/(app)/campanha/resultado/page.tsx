import { CampaignResultView, StoredCampaignResult } from '@/components/campaign/campaign-result'
import { createCampaign } from '@/lib/campaigns/create-campaign'

export default async function ResultadoPage({ searchParams }: { searchParams: Promise<{ id?: string }> }) {
  const { id } = await searchParams

  if (id) return <StoredCampaignResult id={id} />

  const sample = await createCampaign({ productId: 'p2', price: 54, objective: 'vendas', channel: 'instagram', variation: 0 })
  if (!sample.ok) return null

  return <CampaignResultView campaign={sample.campaign} isSample />
}
