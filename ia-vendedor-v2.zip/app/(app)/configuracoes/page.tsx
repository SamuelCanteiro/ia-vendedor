import Link from 'next/link'
import { Camera as Instagram, LogOut, MessageCircle, ThumbsUp as Facebook } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { FormField, FormSection } from '@/components/form-field'
import { demoUser } from '@/lib/demo-data'

const integrations = [
  { name: 'Instagram', icon: Instagram, connected: true },
  { name: 'WhatsApp Business', icon: MessageCircle, connected: true },
  { name: 'Facebook', icon: Facebook, connected: false },
]

export default function ConfiguracoesPage() {
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader eyebrow="Configurações" title="Conta e preferências" />
      <div className="flex flex-col gap-6">
        <FormSection title="Perfil">
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Nome" htmlFor="s-name">
              <input id="s-name" className="field" defaultValue={demoUser.fullName} />
            </FormField>
            <FormField label="E-mail" htmlFor="s-email">
              <input id="s-email" type="email" className="field" defaultValue={demoUser.email} />
            </FormField>
          </div>
        </FormSection>

        <FormSection title="Redes conectadas" description="Demonstração — nenhuma conexão real é feita nesta versão.">
          <ul className="flex flex-col gap-2">
            {integrations.map((i) => {
              const Icon = i.icon
              return (
                <li key={i.name} className="flex items-center gap-3 rounded-xl border border-border p-3">
                  <Icon className="size-5 text-primary" aria-hidden="true" />
                  <span className="flex-1 text-sm font-medium">{i.name}</span>
                  {i.connected ? (
                    <span className="rounded-full bg-success/12 px-2.5 py-1 text-xs font-medium text-success">Conectado</span>
                  ) : (
                    <button type="button" className="btn-outline h-8 px-3 text-xs">
                      Conectar
                    </button>
                  )}
                </li>
              )
            })}
          </ul>
        </FormSection>

        <FormSection title="Plano">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-semibold">
                Plano Pro <span className="text-sm font-normal text-muted-foreground">· R$ 79/mês</span>
              </p>
              <p className="text-sm text-muted-foreground">Campanhas ilimitadas e atendimento IA.</p>
            </div>
            <button type="button" className="btn-outline">
              Gerenciar plano
            </button>
          </div>
        </FormSection>

        <Link href="/" className="btn-outline self-start text-destructive">
          <LogOut className="size-4" aria-hidden="true" />
          Sair da conta
        </Link>
      </div>
    </div>
  )
}
