import Link from 'next/link'
import { Clapperboard, FileText, Hash, ImageIcon, Plus } from 'lucide-react'
import { PageHeader } from '@/components/page-header'
import { contentLibrary } from '@/lib/demo-data'

const typeIcon = { Arte: ImageIcon, Roteiro: Clapperboard, Texto: FileText, Legenda: Hash } as const

export default function ConteudoPage() {
  return (
    <>
      <PageHeader
        eyebrow="Conteúdo"
        title="Biblioteca de conteúdo"
        description="Todas as artes, textos, roteiros e legendas criados pela IA ficam guardados aqui."
        actions={
          <Link href="/criar-campanha" className="btn-primary">
            <Plus className="size-4" aria-hidden="true" />
            Novo conteúdo
          </Link>
        }
      />
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {contentLibrary.map((item, i) => {
          const Icon = typeIcon[item.type as keyof typeof typeIcon]
          return (
            <li key={item.id}>
              <Link href="/campanha/resultado" className="panel group block overflow-hidden transition-colors hover:border-primary/50">
                <div
                  className="flex aspect-video items-end bg-gradient-to-br from-[oklch(0.42_0.19_262)] to-[oklch(0.2_0.06_262)] p-4"
                  style={{ filter: `hue-rotate(${i * 8}deg)` }}
                >
                  <p className="text-lg font-bold text-balance text-white">{item.title}</p>
                </div>
                <div className="flex items-center justify-between p-4">
                  <span className="flex items-center gap-2 text-sm font-medium">
                    <Icon className="size-4 text-primary" aria-hidden="true" />
                    {item.type} · {item.network}
                  </span>
                  <span className="text-xs text-muted-foreground">{item.date}</span>
                </div>
              </Link>
            </li>
          )
        })}
      </ul>
    </>
  )
}
