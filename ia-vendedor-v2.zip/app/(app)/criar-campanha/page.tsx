import { PageHeader } from '@/components/page-header'
import { CampaignWizard } from '@/components/campaign/campaign-wizard'
import { getProducts } from '@/lib/data/catalog'

export default async function CriarCampanhaPage({ searchParams }: { searchParams: Promise<{ produto?: string }> }) {
  const [{ produto }, products] = await Promise.all([searchParams, getProducts()])

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        eyebrow="Criar campanha"
        title="Criador de campanha com IA"
        description="Escolha o produto, o preço, o objetivo e o canal. A IA cria título, texto de venda, legenda, roteiro de Reel e mensagem de WhatsApp."
      />
      <CampaignWizard products={products} initialProductId={produto} />
    </div>
  )
}
