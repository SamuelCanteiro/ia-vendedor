import { PageHeader } from '@/components/page-header'
import { StatCards } from '@/components/dashboard/stat-cards'
import { PerformanceChart } from '@/components/dashboard/performance-chart'

const channels = [
  { name: 'Instagram', share: 58 },
  { name: 'WhatsApp', share: 27 },
  { name: 'Facebook', share: 15 },
]

const topProducts = [
  { name: 'Caixa com 12 Brigadeiros Gourmet', sales: 142 },
  { name: 'Bolo de Chocolate Belga', sales: 64 },
  { name: 'Kit Festa 50 pessoas', sales: 18 },
]

export default function EstatisticasPage() {
  return (
    <>
      <PageHeader eyebrow="Estatísticas" title="Desempenho do seu negócio" description="Resultados dos últimos 30 dias em todos os canais." />
      <div className="flex flex-col gap-6">
        <StatCards />
        <PerformanceChart />
        <div className="grid gap-6 lg:grid-cols-2">
          <section className="panel p-5 sm:p-6" aria-labelledby="by-channel">
            <h2 id="by-channel" className="mb-5 font-semibold">
              Alcance por canal
            </h2>
            <ul className="flex flex-col gap-4">
              {channels.map((c) => (
                <li key={c.name}>
                  <div className="mb-1.5 flex justify-between text-sm">
                    <span>{c.name}</span>
                    <span className="font-semibold">{c.share}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${c.share}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          </section>
          <section className="panel p-5 sm:p-6" aria-labelledby="top-products">
            <h2 id="top-products" className="mb-5 font-semibold">
              Produtos mais vendidos
            </h2>
            <ol className="flex flex-col gap-3">
              {topProducts.map((p, i) => (
                <li key={p.name} className="flex items-center gap-3">
                  <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/12 text-sm font-bold text-primary">
                    {i + 1}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-sm">{p.name}</span>
                  <span className="text-sm font-semibold">{p.sales} vendas</span>
                </li>
              ))}
            </ol>
          </section>
        </div>
      </div>
    </>
  )
}
