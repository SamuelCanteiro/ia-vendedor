import Link from 'next/link'
import { ArrowRight, Lightbulb, Sparkles, WandSparkles } from 'lucide-react'
import { StatCards } from '@/components/dashboard/stat-cards'
import { PerformanceChart } from '@/components/dashboard/performance-chart'
import { aiSuggestions, demoUser, recentCampaigns } from '@/lib/demo-data'
import { cn } from '@/lib/utils'

const statusStyle: Record<string, string> = {
  Ativa: 'bg-success/12 text-success',
  Concluída: 'bg-muted text-muted-foreground',
  Agendada: 'bg-primary/12 text-primary',
}

export default function InicioPage() {
  return (
    <div className="flex flex-col gap-6">
      <section className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-[oklch(0.3_0.12_262)] via-card to-card p-6 sm:p-8">
        <div aria-hidden="true" className="pointer-events-none absolute -top-24 -right-16 size-72 rounded-full bg-primary/30 blur-[90px]" />
        <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Quarta-feira, 10 de junho</p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-balance sm:text-3xl">
              Bom dia, {demoUser.name}! Vamos vender mais hoje?
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
              Sua última campanha alcançou <span className="font-semibold text-foreground">12,4 mil pessoas</span>. A IA
              preparou novas ideias para o Dia dos Namorados.
            </p>
          </div>
          <Link href="/criar-campanha" className="btn-primary h-12 shrink-0">
            <WandSparkles className="size-4" aria-hidden="true" />
            Criar campanha com IA
          </Link>
        </div>
      </section>

      <StatCards />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <PerformanceChart />
        </div>

        <section className="panel p-5 sm:p-6" aria-labelledby="ai-tips">
          <h2 id="ai-tips" className="flex items-center gap-2 font-semibold">
            <Sparkles className="size-4 text-primary" aria-hidden="true" />
            Dicas da IA
          </h2>
          <ul className="mt-4 flex flex-col gap-3">
            {aiSuggestions.map((tip) => (
              <li key={tip} className="flex gap-3 rounded-xl border border-border bg-background/50 p-3.5 text-sm leading-relaxed">
                <Lightbulb className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                {tip}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="panel" aria-labelledby="recent">
        <div className="flex items-center justify-between p-5 sm:p-6">
          <h2 id="recent" className="font-semibold">
            Campanhas recentes
          </h2>
          <Link href="/conteudo" className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
            Ver todas <ArrowRight className="size-3.5" aria-hidden="true" />
          </Link>
        </div>
        <ul className="divide-y divide-border border-t border-border">
          {recentCampaigns.map((c) => (
            <li key={c.id}>
              <Link
                href="/campanha/resultado"
                className="flex items-center gap-4 px-5 py-4 transition-colors hover:bg-accent/40 sm:px-6"
              >
                <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
                  <WandSparkles className="size-4.5" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{c.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {c.channel} · {c.date}
                  </p>
                </div>
                <div className="hidden text-right sm:block">
                  <p className="text-sm font-medium">{c.reach}</p>
                  <p className="text-xs text-muted-foreground">alcance</p>
                </div>
                <span className={cn('rounded-full px-2.5 py-1 text-[11px] font-semibold', statusStyle[c.status])}>
                  {c.status}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
