import { PageHeader } from '@/components/page-header'
import { StoreTabs } from '@/components/store/store-tabs'
import { CompanyForm } from '@/components/store/company-form'

export default function MinhaLojaPage() {
  return (
    <>
      <PageHeader
        eyebrow="Minha loja"
        title="Cadastro da empresa"
        description="Conte para a IA sobre o seu negócio. Quanto mais detalhes, melhores e mais personalizadas serão suas campanhas."
      />
      <StoreTabs />
      <CompanyForm />
    </>
  )
}
