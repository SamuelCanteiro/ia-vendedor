import { AuthForm } from '@/components/auth/auth-form'
import { AuthShowcase } from '@/components/auth/auth-showcase'
import { BrandLogo } from '@/components/brand-logo'

export default function LoginPage() {
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <AuthShowcase />
      <main className="relative flex flex-col items-center justify-center px-5 py-10 sm:px-8">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute top-0 right-0 size-72 rounded-full bg-primary/15 blur-[100px] lg:hidden"
        />
        <BrandLogo className="relative mb-10 lg:hidden" />
        <div className="relative w-full max-w-md">
          <AuthForm />
        </div>
      </main>
    </div>
  )
}
