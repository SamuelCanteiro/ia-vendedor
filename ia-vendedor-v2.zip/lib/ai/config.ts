export type AIConfig = {
  apiKey: string
  model: string
  baseUrl: string
}

export function getAIConfig(): AIConfig | null {
  const apiKey = process.env.AI_API_KEY?.trim()
  if (!apiKey) return null

  return {
    apiKey,
    model: process.env.AI_MODEL?.trim() || 'gpt-4o-mini',
    baseUrl: (process.env.AI_BASE_URL?.trim() || 'https://api.openai.com/v1').replace(/\/$/, ''),
  }
}

export function isAIConfigured() {
  return Boolean(process.env.AI_API_KEY?.trim())
}
