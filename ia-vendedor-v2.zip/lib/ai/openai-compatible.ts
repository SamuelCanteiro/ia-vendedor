import { getAIConfig } from '@/lib/ai/config'

export type ChatMessage = {
  role: 'system' | 'user' | 'assistant'
  content: string
}

export async function generateJSON<T>(messages: ChatMessage[], schemaHint: string): Promise<T> {
  const config = getAIConfig()
  if (!config) throw new Error('AI_NOT_CONFIGURED')

  const response = await fetch(`${config.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${config.apiKey}`,
    },
    body: JSON.stringify({
      model: config.model,
      temperature: 0.8,
      response_format: { type: 'json_object' },
      messages: [
        ...messages,
        {
          role: 'system',
          content: `Return ONLY valid JSON. Follow this output shape exactly: ${schemaHint}`,
        },
      ],
    }),
    cache: 'no-store',
  })

  if (!response.ok) {
    const detail = await response.text().catch(() => '')
    throw new Error(`AI_REQUEST_FAILED:${response.status}:${detail.slice(0, 300)}`)
  }

  const data = (await response.json()) as {
    choices?: Array<{ message?: { content?: string | null } }>
  }
  const content = data.choices?.[0]?.message?.content?.trim()
  if (!content) throw new Error('AI_EMPTY_RESPONSE')

  const cleaned = content.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/, '')
  return JSON.parse(cleaned) as T
}
