import { generateJSON, type ChatMessage } from '@/lib/ai/openai-compatible'
import { getAIConfig } from '@/lib/ai/config'
import { getCompany, getProducts } from '@/lib/data/catalog'
import { formatBRL, type Product } from '@/lib/demo-data'

export type SalesMessage = { role: 'user' | 'assistant'; content: string }

export type SalesReply = {
  reply: string
  intent: 'duvida' | 'produto' | 'compra' | 'entrega' | 'outro'
}

function localFallback(text: string, products: Product[]) {
  const lower = text.toLowerCase()
  const product = products.find((p) => lower.includes(p.name.toLowerCase().split(' ')[0]))
  if (product) {
    if (product.status === 'Esgotado' || product.stock <= 0) return { reply: `No momento, o ${product.name} está esgotado. Posso te apresentar outra opção do nosso catálogo?`, intent: 'produto' as const }
    return { reply: `Claro! O ${product.name} custa ${formatBRL(product.price)} e está disponível. Quer que eu te ajude a montar o pedido?`, intent: 'produto' as const }
  }
  if (lower.includes('entrega') || lower.includes('entregam')) return { reply: 'Sim! Posso verificar as informações de entrega cadastradas pela loja. Qual é o seu bairro ou endereço?', intent: 'entrega' as const }
  return { reply: 'Claro! Posso te ajudar com produtos, preços e pedidos. O que você gostaria de encomendar?', intent: 'duvida' as const }
}

export async function generateSalesReply(history: SalesMessage[]): Promise<SalesReply> {
  const [company, products] = await Promise.all([getCompany(), getProducts()])
  const last = history[history.length - 1]?.content || ''
  if (!getAIConfig()) return localFallback(last, products)

  const messages: ChatMessage[] = [
    {
      role: 'system',
      content:
        'Você é o vendedor virtual de uma pequena empresa brasileira. Responda com naturalidade e objetividade. Use exclusivamente os dados da empresa e do catálogo. Nunca invente preço, estoque, taxa, prazo, desconto ou política. Se uma informação não estiver disponível, diga que precisa confirmar. Conduza a conversa para uma compra quando fizer sentido.',
    },
    {
      role: 'user',
      content: JSON.stringify({ empresa: company, catalogo: products, historico: history.slice(-12) }),
    },
  ]

  const result = await generateJSON<SalesReply>(messages, '{"reply":"string","intent":"duvida|produto|compra|entrega|outro"}')
  if (!result.reply) throw new Error('AI_EMPTY_SALES_REPLY')
  return {
    reply: result.reply,
    intent: ['duvida', 'produto', 'compra', 'entrega', 'outro'].includes(result.intent) ? result.intent : 'outro',
  }
}
